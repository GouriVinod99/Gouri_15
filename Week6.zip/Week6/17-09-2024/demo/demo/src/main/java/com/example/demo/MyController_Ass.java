package com.example.demo;

import com.example.demo.Person_Ass;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MyController_Ass {

    @GetMapping("/person")
    public com.example.demo.Person_Ass getPerson() {
        // Create a sample Person object
    	Person_Ass person = new Person_Ass("John", "Doe", 30);
        return person; // This will be automatically converted to JSON format by Spring Boot
    }
}
