package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestController {
	
	@GetMapping("/hello")
	public String met() {
		return "Hello123";
	}
	@GetMapping("/url")
	public String met3()
		{
			return "This is one more URL";
		}
	}

