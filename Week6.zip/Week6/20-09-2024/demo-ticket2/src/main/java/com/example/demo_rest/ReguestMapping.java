package com.example.demo_rest;

public @interface ReguestMapping {

}
